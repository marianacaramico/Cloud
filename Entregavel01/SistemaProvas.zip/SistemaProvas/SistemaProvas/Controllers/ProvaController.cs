﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.SqlClient;
using SistemaProvas.Models;

namespace SistemaProvas.Controllers
{
    public class ProvaController
    {
        public bool Post([FromBody]Prova prova)
        {
            return Prova.CreateProva(prova);
        }

        public bool Put(int id, [FromBody]Prova prova)
        {
            return Prova.UpdateProva(id, prova);
        }

        public bool Delete(int id)
        {
            return Prova.DeleteProva(id);
        }

        [HttpPost]
        public bool LinkQuestao([FromBody]ProvaQuestao provaQuestao)
        {
            return ProvaQuestao.InsertQuestaoIntoProva(provaQuestao);
        }

        [HttpGet]
        public bool UnlinkQuestao(int idProva, int idQuestao)
        {
            return ProvaQuestao.RemoveQuestaoFromProva(idProva, idQuestao);
        }
    }
}