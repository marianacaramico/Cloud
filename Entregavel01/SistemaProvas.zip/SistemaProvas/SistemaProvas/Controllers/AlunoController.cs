﻿using SistemaProvas.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SistemaProvas.Controllers
{
    public class AlunoController : ApiController
    {
        // POST api/<controller>
        public void Post([FromBody]Aluno aluno)
        {
            Aluno.CreateAluno(aluno);
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]Aluno aluno)
        {
            Aluno.UpdateAluno(id, aluno);
        }
        
        public void Delete(int id)
        {
            Aluno.DeleteAluno(id);
        }
    }
}