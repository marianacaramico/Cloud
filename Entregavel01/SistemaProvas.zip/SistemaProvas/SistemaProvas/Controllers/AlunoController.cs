﻿using SistemaProvas.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SistemaProvas.Controllers
{
    public class AlunoController : ApiController
    {
        public bool Post([FromBody]Aluno aluno)
        {
            return Aluno.CreateAluno(aluno);
        }
        
        public bool Put(int id, [FromBody]Aluno aluno)
        {
            return Aluno.UpdateAluno(id, aluno);
        }
        
        public bool Delete(int id)
        {
            return Aluno.DeleteAluno(id);
        }
    }
}