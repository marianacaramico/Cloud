﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.SqlClient;
using SistemaProvas.Models;

namespace SistemaProvas.Controllers
{
    public class QuestaoController : ApiController
    {
        public void Post([FromBody]Questao questao)
        {
            Questao.CreateQuestao(questao);
        }
        
        public void Put(int id, [FromBody]Questao questao)
        {
            Questao.UpdateQuestao(id, questao);
        }
        
        public void Delete(int id)
        {
            Questao.DeleteQuestao(id);
        }
    }
}