﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace SistemaProvas.Models
{
    public class Questao
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Enunciado { get; set; }

        public static bool CreateQuestao(Questao questao)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    INSERT INTO Questao(Nome, Enunciado)
                    VALUES (@Nome, @Enunciado)", conn))
                {
                    command.Parameters.AddWithValue("@Nome", questao.Nome);
                    command.Parameters.AddWithValue("@Enunciado", questao.Enunciado);
                    bool var = command.ExecuteNonQuery() > 0;
                    Database.CloseConn();
                    return var;
                }
            }
        }

        public static bool UpdateQuestao(Questao questao)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    UPDATE Questao
                    SET Nome = @Nome, Enunciado = @Enunciado
                    WHERE Id = @Id", conn))
                {
                    command.Parameters.AddWithValue("@Nome", questao.Nome);
                    command.Parameters.AddWithValue("@Enunciado", questao.Enunciado);
                    command.Parameters.AddWithValue("@Id", questao.Id);
                    bool var = command.ExecuteNonQuery() > 0;
                    Database.CloseConn();
                    return var;
                }
            }
        }

        public static bool DeleteQuestao(Questao questao)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    DELETE FROM Questao
                    WHERE Id = @Id", conn))
                {
                    command.Parameters.AddWithValue("@Id", questao.Id);
                    bool var = command.ExecuteNonQuery() > 0;
                    Database.CloseConn();
                    return var;
                }
            }
        }
    }
}