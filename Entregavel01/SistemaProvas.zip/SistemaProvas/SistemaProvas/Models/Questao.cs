﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace SistemaProvas.Models
{
    public class Questao
    {
        public string Nome { get; set; }
        public string Enunciado { get; set; }

        public static bool CreateQuestao(Questao questao)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    INSERT INTO Questao(Nome, Enunciado)
                    VALUES (@Nome, @Enunciado)", conn))
                {
                    command.Parameters.AddWithValue("@Nome", questao.Nome);
                    command.Parameters.AddWithValue("@Enunciado", questao.Enunciado);
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public static bool UpdateQuestao(int id, Questao questao)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    UPDATE Questao
                    SET Nome = @Nome, Enunciado = @Enunciado
                    WHERE Id = @Id", conn))
                {
                    command.Parameters.AddWithValue("@Nome", questao.Nome);
                    command.Parameters.AddWithValue("@Enunciado", questao.Enunciado);
                    command.Parameters.AddWithValue("@Id", id);
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public static bool DeleteQuestao(int id)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    DELETE FROM Questao
                    WHERE Id = @Id", conn))
                {
                    command.Parameters.AddWithValue("@Id", id);
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}