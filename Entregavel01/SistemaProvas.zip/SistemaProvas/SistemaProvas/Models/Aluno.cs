﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace SistemaProvas.Models
{
    public class Aluno
    {
        public int IdAluno { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Ra { get; set; }

        public static bool CreateAluno(Aluno aluno)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    INSERT INTO Aluno(Nome, Email, Ra)
                    VALUES(@Nome, @Email, @Ra)", conn))
                {
                    command.Parameters.AddWithValue("@Nome", aluno.Nome);
                    command.Parameters.AddWithValue("@Email", aluno.Email);
                    command.Parameters.AddWithValue("@Ra", aluno.Ra);
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

    }
}