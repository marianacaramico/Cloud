﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace SistemaProvas.Models
{
    public class Aluno
    {
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Ra { get; set; }

        public static bool CreateAluno(Aluno aluno)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    INSERT INTO Aluno(Nome, Email, RA)
                    VALUES(@Nome, @Email, @Ra)", conn))
                {
                    command.Parameters.AddWithValue("@Nome", aluno.Nome);
                    command.Parameters.AddWithValue("@Email", aluno.Email);
                    command.Parameters.AddWithValue("@Ra", aluno.Ra);
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public static bool UpdateAluno(int idAluno, Aluno aluno)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    UPDATE Aluno SET Nome = @Nome,
                        Email = @Email, RA = @Ra
                    WHERE IdAluno = @Id", conn))
                {
                    command.Parameters.AddWithValue("@Nome", aluno.Nome);
                    command.Parameters.AddWithValue("@Email", aluno.Email);
                    command.Parameters.AddWithValue("@Ra", aluno.Ra);
                    command.Parameters.AddWithValue("@Id", idAluno);
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public static bool DeleteAluno(int idAluno)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    DELETE FROM Aluno WHERE IdAluno = @Id", conn))
                {
                    command.Parameters.AddWithValue("@Id", idAluno);
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

    }
}