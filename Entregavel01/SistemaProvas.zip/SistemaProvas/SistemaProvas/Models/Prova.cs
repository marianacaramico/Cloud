﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace SistemaProvas.Models
{
    public class Prova
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public DateTime DataAplicacao { get; set; }

        public static bool CreateProva(Prova prova)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    INSERT INTO Prova(Nome, DataAplicacao)
                    VALUES (@Nome, @DataAplicacao)", conn))
                {
                    command.Parameters.AddWithValue("@Nome", prova.Nome);
                    command.Parameters.AddWithValue("@DataAplicacao", prova.DataAplicacao);
                    bool var = command.ExecuteNonQuery() > 0;
                    Database.CloseConn();
                    return var;
                }
            }
        }

        public static bool UpdateProva(Prova prova)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    UPDATE Prova
                    SET Nome = @Nome, DataAplicacao = @DataAplicacao
                    WHERE IdProva = @Id", conn))
                {
                    command.Parameters.AddWithValue("@Nome", prova.Nome);
                    command.Parameters.AddWithValue("@DataAplicacao", prova.DataAplicacao);
                    command.Parameters.AddWithValue("@Id", prova.Id);
                    bool var = command.ExecuteNonQuery() > 0;
                    Database.CloseConn();
                    return var;
                }
            }
        }

        public static bool DeleteProva(Prova prova)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    DELETE FROM Prova
                    WHERE IdProva = @Id", conn))
                {
                    command.Parameters.AddWithValue("@Id", prova.Id);
                    bool var = command.ExecuteNonQuery() > 0;
                    Database.CloseConn();
                    return var;
                }
            }
        }
    }
}