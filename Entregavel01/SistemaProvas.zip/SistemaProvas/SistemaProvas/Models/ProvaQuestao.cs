﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SistemaProvas.Models
{
    public class ProvaQuestao
    {
        public int IdProva { get; set; }
        public int IdQuestao { get; set; }
        public float Valor { get; set; }

        public static bool InsertQuestaoIntoProva(ProvaQuestao provaQuestao)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    INSERT INTO ProvaQuestao(IdProva, IdQuestao, Valor)
                    VALUES (@IdProva, @IdQuestao, @Valor)", conn))
                {
                    command.Parameters.AddWithValue("@IdProva", provaQuestao.IdProva);
                    command.Parameters.AddWithValue("@IdQuestao", provaQuestao.IdQuestao);
                    command.Parameters.AddWithValue("@Valor", provaQuestao.Valor);
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }

        public static bool RemoveQuestaoFromProva(int idProva, int idQuestao)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    DELETE FROM ProvaQuestao WHERE IdProva = @IdProva AND IdQuestao = @IdQuestao", conn))
                {
                    command.Parameters.AddWithValue("@IdProva", idProva);
                    command.Parameters.AddWithValue("@IdQuestao", idQuestao);
                    return command.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}