﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SistemaProvas.Models
{
    public class ProvaQuestao
    {
        public int IdProva { get; set; }
        public int IdQuestao { get; set; }
        public float Valor { get; set; }

        public static bool InsertQuestaoIntoProva(int idProva, int idQuestao, float valor)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    INSERT INTO ProvaQuestao(IdProva, IdQuestao, Valor)
                    VALUES (@IdProva, @IdQuestao, @Valor)", conn))
                {
                    command.Parameters.AddWithValue("@IdProva", idProva);
                    command.Parameters.AddWithValue("@IdQuestao", idQuestao);
                    command.Parameters.AddWithValue("@Valor", valor);
                    bool result = command.ExecuteNonQuery() > 0;
                    Database.CloseConn();
                    return result;
                }
            }
        }

        public static bool RemoveQuestaoFromProva(int idProva, int idQuestao)
        {
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    DELETE FROM ProvaQuestao WHERE IdProva = @IdProva AND IdQuestao = @IdQuestao", conn))
                {
                    command.Parameters.AddWithValue("@IdProva", idProva);
                    command.Parameters.AddWithValue("@IdQuestao", idQuestao);
                    bool result = command.ExecuteNonQuery() > 0;
                    Database.CloseConn();
                    return result;
                }
            }
        }
    }
}