﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace SistemaProvas
{
    public class Database
    {
        private static string connectionString = "Server=tcp:projetoagenda.database.windows.net,1433;Initial Catalog=agenda;Persist Security Info=False;User ID=Anonimy;Password=Mateuss14la;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        private static SqlConnection conn = null;

        public static SqlConnection GetConn()
        {
            if(conn == null)
            {
                conn = new SqlConnection(connectionString);
            } return conn;
        }

        public static void CloseConn()
        {
            if(conn != null)
            {
                conn.Close();
            }
        }
        
    }
}