﻿using Azure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProjetoImagem.Models;
using System.Data.SqlClient;

namespace ProjetoImagem.Controllers
{
    public class PessoaController : Controller
    {
        // GET: Pessoas
        public ActionResult Index()
        {
            List<Pessoa> lista = new List<Pessoa>();
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand cmd = new SqlCommand("SELECT IdPessoa, Nome, Email FROM Pessoa ORDER BY IdPessoa ASC", conn))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read() == true)
                        {
                            int id = reader.GetInt32(0);
                            string nome = reader.GetString(1);
                            string email = reader.GetString(2);

                            Pessoa pessoa = new Pessoa()
                            {
                                ID = id,
                                Nome = nome,
                                Email = email
                            };

                            lista.Add(pessoa);
                        }
                    }
                }
            }

            return View(lista);
        }

        public ActionResult Incluir(Pessoa pessoa)
        {
            bool result = false;
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    INSERT INTO Pessoa(Nome, Email) OUTPUT INSERTED.IdPessoa
                    VALUES(@Nome, @Email)
                    ", conn))
                {
                    command.Parameters.AddWithValue("Nome", pessoa.Nome);
                    command.Parameters.AddWithValue("Email", pessoa.Email);
                    int idPessoa = (int)command.ExecuteScalar();
                    if (idPessoa > 0)
                    {
                        result = true;
                        if (Request.Files.Count > 0)
                        {
                            AzureStorage.Upload(
                                "web",
                                idPessoa + ".jpg",
                                Request.Files[0].InputStream,
                                "teste",
                                "UseDevelopmentStorage=true"
                            );
                        }
                    }
                }
            }
            return Json(result);
        }

        public ActionResult Editar(Pessoa pessoa)
        {
            bool result = false;
            using (SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    UPDATE Pessoa
                    SET Nome = @Nome, Email = @Email
                    WHERE IdPessoa = @Id
                    ", conn))
                {
                    command.Parameters.AddWithValue("Nome", pessoa.Nome);
                    command.Parameters.AddWithValue("Email", pessoa.Email);
                    command.Parameters.AddWithValue("Id", pessoa.ID);
                    if (command.ExecuteNonQuery() > 0)
                    {
                        result = true;
                        if (Request.Files.Count > 0)
                        {
                            AzureStorage.Upload(
                                "web",
                                pessoa.ID + ".jpg",
                                Request.Files[0].InputStream,
                                "teste",
                                "UseDevelopmentStorage=true"
                            );
                        }
                    }
                }
            }
            return Json(result);
        }

        public ActionResult Excluir(int id)
        {
            bool result;
            using(SqlConnection conn = Database.GetConn())
            {
                using (SqlCommand command = new SqlCommand(@"
                    DELETE FROM Pessoa
                    WHERE IdPessoa = @id
                    ", conn))
                {
                    command.Parameters.AddWithValue("id", id);
                    if (command.ExecuteNonQuery() > 0) result = true;
                    else result = false;
                }
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
}